#!/bin/zsh

set -euo pipefail

VERSION="0.4.38"
EXPECTED_SHA256="e7bab7f044c90a983ae0e0967f3cf8993b914cd73a086b2c69e148a70d9e3a44"
REPO="codejota/jorlas"

GH=""
for candidate in /opt/homebrew/bin/gh /usr/local/bin/gh /usr/bin/gh; do
    if [[ -x "$candidate" ]]; then
        GH="$candidate"
        break
    fi
done

if [[ -z "$GH" ]]; then
    echo "GitHub CLI is required to install private Jorlas releases." >&2
    exit 1
fi

if ! "$GH" auth status --hostname github.com >/dev/null 2>&1; then
    echo "Jorlas is private. Run: gh auth login" >&2
    exit 1
fi

TMP_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/jorlas-install.XXXXXX")"
DMG="$TMP_ROOT/Jorlas-$VERSION.dmg"
MOUNT="$TMP_ROOT/mount"
TARGET="/Applications/Jorlas.app"
STAGED_TARGET="/Applications/.Jorlas.installing.$PPID"
BACKUP_TARGET="/Applications/.Jorlas.previous.$PPID"
MOUNTED=0

cleanup() {
    if [[ "$MOUNTED" == "1" ]]; then
        /usr/bin/hdiutil detach "$MOUNT" -quiet >/dev/null 2>&1 || true
    fi
    if [[ -e "$BACKUP_TARGET" && ! -e "$TARGET" ]]; then
        /bin/mv "$BACKUP_TARGET" "$TARGET" >/dev/null 2>&1 || true
    fi
    rm -rf "$STAGED_TARGET" "$BACKUP_TARGET" "$TMP_ROOT"
}
trap cleanup EXIT INT TERM

if ! "$GH" release download "v$VERSION" \
    --repo "$REPO" \
    --pattern "Jorlas-$VERSION.dmg" \
    --output "$DMG"; then
    echo "Could not download the private Jorlas release. Confirm that gh is logged in as an account with access to $REPO." >&2
    exit 1
fi

if [[ ! -f "$DMG" ]]; then
    echo "The Jorlas release DMG was not downloaded." >&2
    exit 1
fi

ACTUAL_SHA256="$(/usr/bin/shasum -a 256 "$DMG" | /usr/bin/awk '{print $1}')"
if [[ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]]; then
    echo "Jorlas DMG checksum mismatch." >&2
    exit 1
fi

mkdir -p "$MOUNT"
if ! /usr/bin/hdiutil attach "$DMG" \
    -nobrowse -readonly -mountpoint "$MOUNT" \
    >/dev/null; then
    echo "Could not mount the Jorlas DMG." >&2
    exit 1
fi
MOUNTED=1

SOURCE_APP="$MOUNT/Jorlas.app"
INFO_PLIST="$SOURCE_APP/Contents/Info.plist"
if [[ ! -d "$SOURCE_APP" || ! -f "$INFO_PLIST" ]]; then
    echo "Jorlas.app was not found inside the private release DMG." >&2
    exit 1
fi

SOURCE_ID="$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$INFO_PLIST" 2>/dev/null || true)"
SOURCE_VERSION="$(/usr/libexec/PlistBuddy -c 'Print CFBundleShortVersionString' "$INFO_PLIST" 2>/dev/null || true)"
if [[ "$SOURCE_ID" != "com.jorlas.app" || "$SOURCE_VERSION" != "$VERSION" ]]; then
    echo "The downloaded Jorlas.app does not match the expected release." >&2
    exit 1
fi

if ! /usr/bin/codesign --verify --deep --strict "$SOURCE_APP" >/dev/null 2>&1; then
    echo "The downloaded Jorlas.app failed code-signature verification." >&2
    exit 1
fi

/usr/bin/osascript -e 'tell application id "com.jorlas.app" to quit' >/dev/null 2>&1 || true
for _ in {1..20}; do
    if ! /usr/bin/pgrep -x Jorlas >/dev/null 2>&1; then
        break
    fi
    /bin/sleep 0.1
done

rm -rf "$STAGED_TARGET" "$BACKUP_TARGET"
/usr/bin/ditto "$SOURCE_APP" "$STAGED_TARGET"

if ! /usr/bin/codesign --verify --deep --strict "$STAGED_TARGET" >/dev/null 2>&1; then
    echo "The staged Jorlas.app failed code-signature verification." >&2
    exit 1
fi

if [[ -e "$TARGET" ]]; then
    /bin/mv "$TARGET" "$BACKUP_TARGET"
fi

if ! /bin/mv "$STAGED_TARGET" "$TARGET"; then
    echo "Jorlas.app could not be installed in /Applications." >&2
    exit 1
fi

rm -rf "$BACKUP_TARGET"

if [[ ! -d "$TARGET" ]]; then
    echo "Jorlas.app could not be installed in /Applications." >&2
    exit 1
fi
